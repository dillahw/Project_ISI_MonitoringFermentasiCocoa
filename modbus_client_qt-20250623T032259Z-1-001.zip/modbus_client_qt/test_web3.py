from web3 import Web3

# Ganti dengan URL endpoint dari Infura
infura_url = 'https://mainnet.infura.io/v3/d8f8c197394a4070beb5c16cdfa4d84d'
web3 = Web3(Web3.HTTPProvider(infura_url))

if web3.is_connected():
    print("Koneksi berhasil ke Ethereum node")
    print("Block terakhir:", web3.eth.block_number)
else:
    print("Koneksi gagal")
