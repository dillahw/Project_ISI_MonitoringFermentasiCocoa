from PyQt5.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget, QPushButton
from web3 import Web3

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Web3 setup
        infura_url = 'https://mainnet.infura.io/v3/<PROJECT_ID>'
        self.web3 = Web3(Web3.HTTPProvider(infura_url))

        self.label = QLabel("Klik untuk ambil block terakhir")
        self.button = QPushButton("Ambil Block")

        self.button.clicked.connect(self.show_block_number)

        layout = QVBoxLayout()
        layout.addWidget(self.label)
        layout.addWidget(self.button)

        self.setLayout(layout)
        self.setWindowTitle("Info Blockchain")

    def show_block_number(self):
        if self.web3.is_connected():
            block = self.web3.eth.block_number
            self.label.setText(f"Block terakhir: {block}")
        else:
            self.label.setText("Koneksi gagal")

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())
