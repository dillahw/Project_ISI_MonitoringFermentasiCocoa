import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QTextEdit
import pyqtgraph as pg
from influxdb_client import InfluxDBClient
from datetime import datetime

class InfluxMonitor(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.connectInfluxDB()

    def initUI(self):
        self.setWindowTitle("Monitoring InfluxDB dengan Grafik")
        self.resize(800, 600)

        layout = QVBoxLayout()

        # Widget output teks
        self.output = QTextEdit()
        self.output.setReadOnly(True)
        layout.addWidget(self.output)

        # Tombol refresh
        self.refresh_btn = QPushButton("Refresh Data")
        self.refresh_btn.clicked.connect(self.loadData)
        layout.addWidget(self.refresh_btn)

        # Widget grafik
        self.graphWidget = pg.PlotWidget()
        self.graphWidget.setBackground('w')
        layout.addWidget(self.graphWidget)

        self.setLayout(layout)

    def connectInfluxDB(self):
        self.token = "g3XcrGyuD-wA56C9w2JxJ6LYqXQaESzxIerq5H54e_-yLgo_dD9P-jxWNjw9_-YBK8m-i3oB38WXMwBODBqcdQ=="
        self.org = "kopi"
        self.bucket = "SHT20"
        self.url = "http://localhost:8086"
        self.client = InfluxDBClient(url=self.url, token=self.token, org=self.org)
        self.query_api = self.client.query_api()

    def loadData(self):
        self.output.clear()
        self.graphWidget.clear()

        query = f'''
        from(bucket: "{self.bucket}")
        |> range(start: -1h)
        |> filter(fn: (r) => r._measurement == "environment_monitoring")
        |> filter(fn: (r) => r._field == "temperature_celsius")
        |> filter(fn: (r) => r.location == "Gudang Fermentasi 1")
        |> filter(fn: (r) => r.process_stage == "Fermentasi")
        |> filter(fn: (r) => r.sensor_id == "SHT20-PascaPanen-001")
        '''

        try:
            print("Menjalankan query...")
            print(query)

            tables = self.query_api.query(query)

            times = []
            values = []

            for table in tables:
                for record in table.records:
                    waktu = record.get_time().timestamp()
                    nilai = record.get_value()

                    times.append(waktu)
                    values.append(nilai)

                    # Output ke QTextEdit
                    text_time = datetime.fromtimestamp(waktu).strftime("%Y-%m-%d %H:%M:%S")
                    line = f"{text_time} | {record.get_field()} | {nilai}"
                    self.output.append(line)

            if times and values:
                self.graphWidget.plot(times, values, pen=pg.mkPen('r', width=2))
                self.graphWidget.setLabel('left', 'Temperature (°C)')
                self.graphWidget.setLabel('bottom', 'Time (Epoch)')
                self.graphWidget.setTitle("Grafik Pembacaan Sensor Suhu")
            else:
                self.output.append("⚠️ Tidak ada data untuk ditampilkan.")

        except Exception as e:
            self.output.append(f"❌ Gagal mengambil data: {e}")

# Main Program
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = InfluxMonitor()
    window.show()
    sys.exit(app.exec_())
