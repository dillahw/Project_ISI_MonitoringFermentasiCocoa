#!/bin/bash

echo "🚀 Memulai Ganache..."
npx ganache --mnemonic "candy maple cake sugar pudding cream honey rich smooth crumble sweet treat" > ganache.log 2>&1 &
sleep 5  # Tunggu Ganache siap

echo "🛠️  Compile smart contract..."
python3 compile_contract.py

echo "📦 Deploy smart contract..."
python3 deploy_contract.py

echo "🌐 Jalankan Flask API..."
python3 contract_api.py > flask.log 2>&1 &

echo "✅ Semua proses selesai dijalankan."