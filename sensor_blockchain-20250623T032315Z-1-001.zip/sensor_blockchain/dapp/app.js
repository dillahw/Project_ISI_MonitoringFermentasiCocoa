let web3;
let contract;
let userAccount;

const contractAddress = "0x8C7e2BA424569c0B1c90bF5dAa66e45a1Cba058E";
const contractABI = [  
  {
    "inputs": [],
    "stateMutability": "nonpayable",
    "type": "constructor"
  },
  {
    "anonymous": false,
    "inputs": [
      { "indexed": true, "internalType": "uint256", "name": "id", "type": "uint256" },
      { "indexed": false, "internalType": "int256", "name": "temperature", "type": "int256" },
      { "indexed": false, "internalType": "uint256", "name": "humidity", "type": "uint256" },
      { "indexed": false, "internalType": "uint256", "name": "timestamp", "type": "uint256" }
    ],
    "name": "DataLogged",
    "type": "event"
  },
  {
    "inputs": [{ "internalType": "uint256", "name": "index", "type": "uint256" }],
    "name": "getReading",
    "outputs": [
      {
        "components": [
          { "internalType": "uint256", "name": "timestamp", "type": "uint256" },
          { "internalType": "int256", "name": "temperature", "type": "int256" },
          { "internalType": "uint256", "name": "humidity", "type": "uint256" }
        ],
        "internalType": "struct SHT20Sensor.SensorData",
        "name": "",
        "type": "tuple"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "getTotalReadings",
    "outputs": [{ "internalType": "uint256", "name": "", "type": "uint256" }],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      { "internalType": "int256", "name": "_temperature", "type": "int256" },
      { "internalType": "uint256", "name": "_humidity", "type": "uint256" }
    ],
    "name": "logData",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  }
];

async function connectMetamask() {
  if (window.ethereum) {
    try {
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      userAccount = accounts[0];
      document.getElementById('status').innerText = '🟢 Connected';

      web3 = new Web3(window.ethereum);
      contract = new web3.eth.Contract(contractABI, contractAddress);

      getLastReading();

    } catch (error) {
      console.error("Metamask error:", error);
    }
  } else {
    alert("Metamask tidak ditemukan");
  }
}

const ctx = document.getElementById('sensorChart').getContext('2d');
const sensorChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: [],
    datasets: [
      {
        label: 'Temperature (°C)',
        data: [],
        borderColor: 'rgba(255,99,132,1)',
        fill: false
      },
      {
        label: 'Humidity (%)',
        data: [],
        borderColor: 'rgba(54,162,235,1)',
        fill: false
      }
    ]
  },
  options: {
    responsive: true,
    scales: {
      y: { beginAtZero: true }
    }
  }
});

function updateChart(temp, humid) {
  const timeLabel = new Date().toLocaleTimeString();
  sensorChart.data.labels.push(timeLabel);
  sensorChart.data.datasets[0].data.push(temp);
  sensorChart.data.datasets[1].data.push(humid);
  sensorChart.update();
}

async function sendData() {
  const sensorId = document.getElementById('sensorId').value;
  const temperature = parseFloat(document.getElementById('temperature').value);
  const humidity = parseFloat(document.getElementById('humidity').value);

  if (isNaN(temperature) || isNaN(humidity)) {
    alert("Masukkan nilai suhu dan kelembaban yang valid!");
    return;
  }

  const response = await fetch('/add_block', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sensor_id: sensorId, temperature, humidity })
  });

  const result = await response.json();
  document.getElementById('latestBlock').innerText = JSON.stringify(result, null, 2);

  updateChart(temperature, humidity);

  try {
    const tempScaled = Math.round(temperature * 100);
    const humidScaled = Math.round(humidity * 100);

    await contract.methods.logData(tempScaled, humidScaled).send({ from: userAccount });

    console.log("Data berhasil disimpan ke blockchain");
    getLastReading();

  } catch (error) {
    console.error("Gagal menyimpan ke blockchain:", error);
  }
}

async function getLastReading() {
  try {
    const total = await contract.methods.getTotalReadings().call();
    const latestIndex = total - 1;

    if (latestIndex >= 0) {
      const reading = await contract.methods.getReading(latestIndex).call();
      const temp = reading.temperature / 100;
      const humid = reading.humidity / 100;

      document.getElementById('latestFromBlockchain').innerText =
        `🌐 Suhu: ${temp} °C | Kelembaban: ${humid}%`;

      updateChart(temp, humid);
    }
  } catch (err) {
    console.error("Gagal ambil data terakhir:", err);
  }
}

async function refreshAllData() {
  const statusEl = document.getElementById('status');
  try {
    statusEl.innerText = '⏳ Mengambil data dari blockchain...';
    const total = await contract.methods.getTotalReadings().call();

    sensorChart.data.labels = [];
    sensorChart.data.datasets[0].data = [];
    sensorChart.data.datasets[1].data = [];

    for (let i = 0; i < total; i++) {
      const reading = await contract.methods.getReading(i).call();
      const temp = reading.temperature / 100;
      const humid = reading.humidity / 100;
      const timestamp = new Date(reading.timestamp * 1000).toLocaleTimeString();

      sensorChart.data.labels.push(timestamp);
      sensorChart.data.datasets[0].data.push(temp);
      sensorChart.data.datasets[1].data.push(humid);
    }

    sensorChart.update();
    statusEl.innerText = `🟢 ${total} data berhasil dimuat dari blockchain`;
  } catch (err) {
    console.error("Gagal refresh data:", err);
    statusEl.innerText = "❌ Gagal refresh dari blockchain!";
  }
}
