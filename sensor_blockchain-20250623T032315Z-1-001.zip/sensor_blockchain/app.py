from flask import Flask, request, jsonify
from web3 import Web3
import json

app = Flask(__name__)

# Koneksi ke Ganache
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))

# Atur akun default (biasanya akun[0] di Ganache)
w3.eth.default_account = w3.eth.accounts[0]

# Load ABI dari file
with open("build/SensorDataABI.json") as f:
    abi = json.load(f)

# Load alamat kontrak
with open("contract_address.txt") as f:
    contract_address = f.read().strip()

# Inisialisasi kontrak
contract = w3.eth.contract(address=contract_address, abi=abi)

# Endpoint untuk menambahkan data
@app.route("/add", methods=["POST"])
def add_data():
    data = request.get_json()

    try:
        # Kirim transaksi ke smart contract
        tx_hash = contract.functions.addData(
            data["sensor_id"],
            int(data["temperature"]),
            int(data["humidity"])
        ).transact()

        return jsonify({"status": "success", "tx_hash": tx_hash.hex()})
    
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

# Endpoint untuk menghitung jumlah data
@app.route("/count", methods=["GET"])
def get_data_count():
    try:
        count = contract.functions.getDataCount().call()
        return jsonify({"status": "success", "count": count})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
