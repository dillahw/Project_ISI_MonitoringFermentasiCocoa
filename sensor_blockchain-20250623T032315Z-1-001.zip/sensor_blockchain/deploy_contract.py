from web3 import Web3
import json

# Koneksi ke Ganache
w3 = Web3(Web3.HTTPProvider("http://127.0.0.1:8545"))
w3.eth.default_account = w3.eth.accounts[0]

# Load ABI
with open("build/SensorDataABI.json", "r") as f:
    abi = json.load(f)

# Load bytecode
with open("build/SensorDataBytecode.txt", "r") as f:
    bytecode = f.read()

# Deploy kontrak
SensorData = w3.eth.contract(abi=abi, bytecode=bytecode)
tx_hash = SensorData.constructor().transact()
tx_receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

# Simpan address ke file
with open("contract_address.txt", "w") as f:
    f.write(tx_receipt.contractAddress)

print(f"Kontrak berhasil dideploy di: {tx_receipt.contractAddress}")
