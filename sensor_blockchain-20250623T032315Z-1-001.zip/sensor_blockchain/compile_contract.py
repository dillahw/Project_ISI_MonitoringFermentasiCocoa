from solcx import compile_source, install_solc, set_solc_version
import json
import os

install_solc("0.8.20")
set_solc_version("0.8.20")  # <-- WAJIB agar digunakan oleh compile_source

with open("SensorData.sol", "r") as f:
    source_code = f.read()

compiled_sol = compile_source(source_code, output_values=["abi", "bin"])
contract_interface = compiled_sol[list(compiled_sol.keys())[0]]

# Buat folder build jika belum ada
os.makedirs("build", exist_ok=True)

# Simpan ABI
with open("build/SensorDataABI.json", "w") as f:
    json.dump(contract_interface["abi"], f)

# Simpan bytecode
with open("build/SensorDataBytecode.txt", "w") as f:
    f.write(contract_interface["bin"])
